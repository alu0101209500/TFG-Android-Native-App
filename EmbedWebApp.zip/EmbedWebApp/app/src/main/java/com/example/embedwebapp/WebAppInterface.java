package com.example.embedwebapp;

import android.content.Context;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;

public class WebAppInterface {
    Context mContext;

    /**
     * Instantiate the interface and set the context
     */
    WebAppInterface(Context c) {
        mContext = c;
    }

    /**
     * Show a toast from the web page
     */
    @JavascriptInterface
    public void showToast(String toast) {
        Toast.makeText(mContext, toast, Toast.LENGTH_SHORT).show();
    }

    @JavascriptInterface
    public void writeCookies(String content) {
        File path = mContext.getFilesDir();
        try {
            FileOutputStream writer = new FileOutputStream(new File(path, "cookies.txt"));
            writer.write(content.getBytes());
            writer.close();
        } catch(Exception e){
            e.printStackTrace();
        }
    }

    @JavascriptInterface
    public String readCookies() {
        File path = mContext.getFilesDir();
        File readFrom = new File(path, "cookies.txt");
        byte[] content = new byte[(int) readFrom.length()];
        try {
            FileInputStream stream = new FileInputStream(readFrom);
            stream.read(content);
            return new String(content);
        } catch(Exception e){
            e.printStackTrace();
            return "{\"authToken\":\"\",\"authUser\":\"\"}";
        }
    }
}
